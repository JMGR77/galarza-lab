import React from 'react';
import { Download, FileText, CheckCircle2 } from 'lucide-react';
import { triggerDownload } from '../data/fuelData';

export const DownloadsSection: React.FC = () => {
  const artifacts = [
    {
      id: 'audit_report',
      title: 'calgary_fuel_forecast_audit_report.csv',
      category: 'AUDIT REPORT',
      rows: '11 scenario records',
      desc: 'Complete production audit trail with historical prices, point forecasts, residual errors, 95% confidence intervals, and circuit breaker flags.',
      badgeColor: 'border-cyan-500/30 text-cyan-400 bg-cyan-500/10',
      buttonColor: 'bg-blue-600 hover:bg-blue-500 text-white',
    },
    {
      id: 'cleaned_data',
      title: 'cleaned_data.csv',
      category: 'RAW CLEANED DATA',
      rows: '1,517 business days',
      desc: 'Full 5-year chronological series (2021–2026) with standardized ISO dates and zero synthetic weekend rows.',
      badgeColor: 'border-slate-700 text-slate-300 bg-slate-800',
      buttonColor: 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700',
    },
    {
      id: 'lag_features',
      title: 'lag_features.csv',
      category: 'FEATURE MATRIX',
      rows: '1,507 records',
      desc: 'Engineered lag matrix containing lag_1, lag_2, lag_5, lag_10, diff_1, diff_5, rolling_mean_5, rolling_std_5, and day_of_week.',
      badgeColor: 'border-blue-500/30 text-blue-400 bg-blue-500/10',
      buttonColor: 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700',
    },
    {
      id: 'train_scaled',
      title: 'train_scaled.csv',
      category: 'SCALED TRAIN PARTITION',
      rows: '1,205 records (80%)',
      desc: 'Standardized training set (2021-01-18 to 2025-07-28) with Z-score scaled features and native ¢/L target.',
      badgeColor: 'border-slate-700 text-slate-300 bg-slate-800',
      buttonColor: 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700',
    },
    {
      id: 'val_scaled',
      title: 'val_scaled.csv',
      category: 'SCALED VALIDATION PARTITION',
      rows: '302 records (20%)',
      desc: 'Out-of-sample validation partition transformed strictly using training scaler parameters (zero forward leakage).',
      badgeColor: 'border-emerald-500/30 text-emerald-400 bg-emerald-500/10',
      buttonColor: 'bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700',
    },
    {
      id: 'metrics',
      title: 'model_comparison_metrics.csv',
      category: 'BENCHMARK METRICS',
      rows: '5 model benchmarks',
      desc: 'Comparative performance matrix evaluating Gradient Boosting, Linear Regression, Baseline, Random Forest, and Decision Tree on MAE, RMSE, MedAE, RMSLE.',
      badgeColor: 'border-amber-500/30 text-amber-400 bg-amber-500/10',
      buttonColor: 'bg-emerald-800/70 hover:bg-emerald-700 text-emerald-100 border border-emerald-600/40',
    },
  ];

  return (
    <section id="downloads" className="space-y-8">
      {/* Header */}
      <div className="border-b border-slate-800/80 pb-6">
        <div className="flex items-center gap-2 text-xs text-cyan-400 font-mono mb-1.5">
          <span>Reproducibility & Data Exports</span>
          <span aria-hidden="true">·</span>
          <span>6 Downloadable CSV Artifacts</span>
          <span aria-hidden="true">·</span>
          <span>In-Browser Client Blob Generation</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Download Pipeline Data Artifacts & Validation Reports
        </h2>
        <p className="text-sm text-slate-400 mt-1 max-w-3xl">
          Every intermediate and final dataset from this Calgary fuel-price econometric study is packaged
          for immediate client-side download without third-party dependencies or external API round-trips.
        </p>
      </div>

      {/* Grid of 6 Download Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {artifacts.map((art) => (
          <div
            key={art.id}
            className="p-5 bg-slate-900/90 rounded-2xl border border-slate-800 hover:border-slate-700 transition-all shadow-sm flex flex-col justify-between"
          >
            <div>
              <div className="flex items-center justify-between text-xs font-mono mb-2">
                <span className={`px-2 py-0.5 rounded text-[10px] font-bold border ${art.badgeColor}`}>
                  {art.category}
                </span>
                <span className="text-slate-400">{art.rows}</span>
              </div>

              <h3 className="text-sm font-bold text-white font-mono break-all mt-1">
                {art.title}
              </h3>

              <p className="text-xs text-slate-400 mt-2.5 leading-relaxed">
                {art.desc}
              </p>
            </div>

            <button
              onClick={() => triggerDownload(art.id)}
              className={`mt-5 w-full py-2.5 px-4 rounded-xl text-xs font-semibold flex items-center justify-center gap-2 transition-colors cursor-pointer shadow-sm ${art.buttonColor}`}
            >
              <Download className="w-4 h-4" />
              <span>Download CSV File</span>
            </button>
          </div>
        ))}
      </div>

      {/* Audit Guarantee Note */}
      <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between text-xs text-slate-400 font-mono">
        <div className="flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>All CSV files formatted with RFC-4180 standard headers and UTF-8 encoding.</span>
        </div>
        <span className="text-slate-500">100% Client-Side Generation</span>
      </div>
    </section>
  );
};
