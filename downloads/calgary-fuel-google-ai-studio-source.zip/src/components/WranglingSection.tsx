import React from 'react';
import { Calendar, HelpCircle, Check, X, ShieldAlert } from 'lucide-react';

export const WranglingSection: React.FC = () => {
  return (
    <section id="wrangling" className="space-y-8">
      {/* Header */}
      <div className="border-b border-slate-800/80 pb-6">
        <div className="flex items-center gap-2 text-xs text-cyan-400 font-mono mb-1.5">
          <span>Feature Engineering Pipeline</span>
          <span aria-hidden="true">·</span>
          <span>DP1 & DP2</span>
          <span aria-hidden="true">·</span>
          <span>Temporal Windowing & Lags</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Data Wrangling: Windowing, Lag Features & Mathematical Rationale
        </h2>
        <p className="text-sm text-slate-400 mt-1 max-w-3xl">
          Detailed justification for rejecting synthetic weekend interpolation, selecting the optimal 5-day
          rolling window, and constructing autoregressive lag features that capture Calgary's asymmetric price cycle
          using strictly past historical observations.
        </p>
      </div>

      {/* DP1: Rejection of Weekend Invention */}
      <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-sm space-y-4">
        <div className="flex items-center gap-2 text-xs font-mono text-cyan-400 font-semibold uppercase tracking-wider">
          <span>DP1 • Calendar Regularity & Cleaning</span>
        </div>
        <h3 className="text-lg font-bold text-white">
          Why Weekend Data Was Intentionally Excluded (Never Interpolated)
        </h3>
        <p className="text-xs text-slate-300 leading-relaxed">
          The Calgary fuel price dataset is compiled on business/trading days (Monday through Friday, excluding statutory holidays),
          yielding 1,517 total records. In amateur time-series pipelines, practitioners often forward-fill or interpolate
          Saturday and Sunday rows to force a 7-day calendar format. In retail petroleum econometrics, this is fundamentally flawed:
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
          <div className="p-4 bg-rose-950/20 border border-rose-500/20 rounded-xl space-y-2">
            <div className="flex items-center gap-2 text-rose-400 text-xs font-bold font-mono">
              <X className="w-4 h-4" />
              <span>Consequences of Weekend Forward-Filling (Flawed)</span>
            </div>
            <ul className="text-xs text-slate-400 space-y-1.5 list-disc list-inside">
              <li>
                <strong className="text-slate-300">Creates Fake Zero-Change Days:</strong> 104 synthetic flat days per year
                distort genuine market volatility distributions.
              </li>
              <li>
                <strong className="text-slate-300">Artificially Inflates Autocorrelation:</strong> Artificially pumps Lag 1
                persistence and hides true price cycle decay rates.
              </li>
              <li>
                <strong className="text-slate-300">Distorts Velocity Metrics:</strong> Rolling averages lag reality because
                they are diluted with static placeholder rows.
              </li>
            </ul>
          </div>

          <div className="p-4 bg-emerald-950/20 border border-emerald-500/20 rounded-xl space-y-2">
            <div className="flex items-center gap-2 text-emerald-400 text-xs font-bold font-mono">
              <Check className="w-4 h-4" />
              <span>Preserving Pure Business Days (Our Approach)</span>
            </div>
            <ul className="text-xs text-slate-400 space-y-1.5 list-disc list-inside">
              <li>
                <strong className="text-slate-300">True Trading Frequency:</strong> Observation index represents consecutive
                trading sessions (t, t-1, t-2, ...).
              </li>
              <li>
                <strong className="text-slate-300">Target Horizon Accuracy:</strong> "Next Day" represents the next recorded
                business session (Friday rolls directly to Monday).
              </li>
              <li>
                <strong className="text-slate-300">Zero Synthetic Bias:</strong> Preserves exact 100% genuine retail price
                movements across all 1,517 days.
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* DP2: 5-Day Window Selection Rationale */}
      <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-sm space-y-5">
        <div className="flex items-center gap-2 text-xs font-mono text-cyan-400 font-semibold uppercase tracking-wider">
          <span>DP2 • Rolling Window Selection</span>
        </div>
        <h3 className="text-lg font-bold text-white">
          Recommended Window Size: 5 Recorded Business Days (Exact 1-Week Alignment)
        </h3>
        <p className="text-xs text-slate-300 leading-relaxed">
          Because weekends are excluded, <strong>5 consecutive recorded observations equal exactly one full calendar business week</strong>.
          A 5-day rolling window captures an entire short-term local price cycle without mixing previous unrelated cycles.
        </p>

        {/* Alternatives Evaluated Table */}
        <div className="border border-slate-800 rounded-xl overflow-hidden bg-slate-950">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-slate-900 text-slate-400 border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Window Size</th>
                <th className="py-3 px-4">Calendar Span</th>
                <th className="py-3 px-4">Evaluation Result</th>
                <th className="py-3 px-4">Reason for Adoption / Rejection</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              <tr className="bg-emerald-950/20 font-semibold text-white">
                <td className="py-3 px-4 text-emerald-400">5 Days (Adopted)</td>
                <td className="py-3 px-4">1.0 Calendar Week</td>
                <td className="py-3 px-4 text-emerald-400">Optimal (Winning)</td>
                <td className="py-3 px-4 font-sans text-xs text-slate-300">
                  Aligns perfectly with the 5-day trading week. Balances responsiveness to sudden price restoration spikes while smoothing day-to-day noise.
                </td>
              </tr>
              <tr>
                <td className="py-3 px-4 text-slate-400">3 Days</td>
                <td className="py-3 px-4">0.6 Calendar Weeks</td>
                <td className="py-3 px-4 text-amber-400">Rejected (High Variance)</td>
                <td className="py-3 px-4 font-sans text-xs text-slate-400">
                  Too noisy during flat or slow erosion phases. Produces erratic rolling standard deviations from single minor pump adjustments.
                </td>
              </tr>
              <tr>
                <td className="py-3 px-4 text-slate-400">7 Days</td>
                <td className="py-3 px-4">1.4 Calendar Weeks</td>
                <td className="py-3 px-4 text-rose-400">Rejected (Phase Distortion)</td>
                <td className="py-3 px-4 font-sans text-xs text-slate-400">
                  In business-day data, 7 rows span 9–10 calendar days. This overlaps two different weekly reset cycles, blurring price velocity signals.
                </td>
              </tr>
              <tr>
                <td className="py-3 px-4 text-slate-400">10 Days</td>
                <td className="py-3 px-4">2.0 Calendar Weeks</td>
                <td className="py-3 px-4 text-slate-400">Secondary (Feature lag_10)</td>
                <td className="py-3 px-4 font-sans text-xs text-slate-400">
                  Too sluggish for point-prediction rolling means, but retained as a standalone lag anchor (lag_10) for bi-weekly baseline comparison.
                </td>
              </tr>
              <tr>
                <td className="py-3 px-4 text-slate-400">20 Days</td>
                <td className="py-3 px-4">1.0 Calendar Month</td>
                <td className="py-3 px-4 text-slate-400">Macro Trend Reference</td>
                <td className="py-3 px-4 font-sans text-xs text-slate-400">
                  Smooths away the entire 5–10 day sawtooth cycle. Incapable of detecting 24-hour retail price restoration jumps.
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Selected Lag Features Matrix */}
      <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-sm space-y-4">
        <h3 className="text-base font-bold text-white">
          Selected Autoregressive Lags & Rolling Feature Matrix
        </h3>
        <p className="text-xs text-slate-400">
          All 9 features are calculated strictly using past observations (t-1, t-2, etc.) to completely eliminate lookahead bias.
        </p>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-2">
          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold text-cyan-400">lag_1 (Y_t-1)</span>
              <span className="text-[11px] font-mono text-slate-500">Price Level Anchor</span>
            </div>
            <p className="text-xs text-slate-300">Immediate prior price.</p>
            <p className="text-[11px] text-slate-400">
              Retail gasoline prices have day-to-day autocorrelation &gt;0.98. Today's price is heavily anchored by yesterday's price.
            </p>
          </div>

          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold text-cyan-400">diff_1 (Y_t-1 - Y_t-2)</span>
              <span className="text-[11px] font-mono text-slate-500">1-Day Velocity</span>
            </div>
            <p className="text-xs text-slate-300">Daily price momentum.</p>
            <p className="text-[11px] text-slate-400">
              A large positive value (&gt; +5¢) flags that an asymmetric cycle reset has commenced, triggering non-linear model adjustments.
            </p>
          </div>

          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold text-cyan-400">lag_2 (Y_t-2)</span>
              <span className="text-[11px] font-mono text-slate-500">Momentum Reference</span>
            </div>
            <p className="text-xs text-slate-300">Price 2 business days ago.</p>
            <p className="text-[11px] text-slate-400">
              Establishes curvature and second derivative of price changes, distinguishing one-day noise from multi-day trends.
            </p>
          </div>

          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold text-cyan-400">lag_5 (Y_t-5)</span>
              <span className="text-[11px] font-mono text-slate-500">1-Week Baseline</span>
            </div>
            <p className="text-xs text-slate-300">Price exactly 1 business week ago.</p>
            <p className="text-[11px] text-slate-400">
              Provides the anchor for weekly cyclical comparisons, establishing where the current day sits relative to last week.
            </p>
          </div>

          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold text-cyan-400">diff_5 (Y_t-1 - Y_t-5)</span>
              <span className="text-[11px] font-mono text-slate-500">5-Day Net Velocity</span>
            </div>
            <p className="text-xs text-slate-300">Weekly net price trajectory.</p>
            <p className="text-[11px] text-slate-400">
              Detects whether the market is in an extended multi-day erosion phase (-4¢ to -8¢ net) or in the midst of a weekly restoration.
            </p>
          </div>

          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold text-cyan-400">lag_10 (Y_t-10)</span>
              <span className="text-[11px] font-mono text-slate-500">Bi-Weekly Macro</span>
            </div>
            <p className="text-xs text-slate-300">Price 2 business weeks ago.</p>
            <p className="text-[11px] text-slate-400">
              Anchors medium-term price trends and prevents the model from over-fitting to localized single-week price fluctuations.
            </p>
          </div>

          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold text-cyan-400">rolling_mean_5</span>
              <span className="text-[11px] font-mono text-slate-500">Smoothed Trend</span>
            </div>
            <p className="text-xs text-slate-300">Mean of past 5 days (t-1 to t-5).</p>
            <p className="text-[11px] text-slate-400">
              Filters out high-frequency station noise; serves as the mean-reversion target during stable market conditions.
            </p>
          </div>

          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold text-cyan-400">rolling_std_5</span>
              <span className="text-[11px] font-mono text-slate-500">Rolling Volatility</span>
            </div>
            <p className="text-xs text-slate-300">5-day standard deviation.</p>
            <p className="text-[11px] text-slate-400">
              Surges immediately upon a price cycle reset; signals to the tree model that the market has transitioned out of calm decay.
            </p>
          </div>

          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold text-cyan-400">day_of_week</span>
              <span className="text-[11px] font-mono text-slate-500">Calendar Index</span>
            </div>
            <p className="text-xs text-slate-300">Monday=0 to Friday=4.</p>
            <p className="text-[11px] text-slate-400">
              Captures human retail scheduling tendencies (e.g., pre-weekend Thursday price hikes and Monday morning competitive adjustments).
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
