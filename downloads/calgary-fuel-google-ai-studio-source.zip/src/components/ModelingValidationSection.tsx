import React, { useState } from 'react';
import {
  Trophy,
  Activity,
  Layers,
  ArrowRight,
  TrendingUp,
  Download,
} from 'lucide-react';
import {
  MODEL_METRICS,
  VALIDATION_SAMPLE_SERIES,
  triggerDownload,
} from '../data/fuelData';

export const ModelingValidationSection: React.FC = () => {
  const [selectedModelKey, setSelectedModelKey] = useState<
    'gradientBoosting' | 'linearReg' | 'baseline' | 'randomForest' | 'decisionTree'
  >('gradientBoosting');

  const modelLabels = {
    gradientBoosting: 'Gradient Boosting (Recommended)',
    linearReg: 'Linear Regression (OLS)',
    baseline: 'Previous-Price Baseline',
    randomForest: 'Random Forest',
    decisionTree: 'Decision Tree',
  };

  const chartHeight = 220;
  const chartWidth = 720;
  const padX = 45;
  const padY = 25;

  const minVal = 145;
  const maxVal = 175;

  const getYPos = (val: number) => {
    const norm = (val - minVal) / (maxVal - minVal);
    return chartHeight - padY - norm * (chartHeight - padY * 2);
  };

  const getXPos = (idx: number, total: number) => {
    return padX + (idx / (total - 1)) * (chartWidth - padX * 2);
  };

  const actualPoints = VALIDATION_SAMPLE_SERIES.map((pt, i) =>
    `${getXPos(i, VALIDATION_SAMPLE_SERIES.length)},${getYPos(pt.actual)}`
  ).join(' ');

  const modelPoints = VALIDATION_SAMPLE_SERIES.map((pt, i) =>
    `${getXPos(i, VALIDATION_SAMPLE_SERIES.length)},${getYPos(pt[selectedModelKey])}`
  ).join(' ');

  return (
    <section id="modeling" className="space-y-8">
      {/* Header */}
      <div className="border-b border-slate-800/80 pb-6">
        <div className="flex items-center gap-2 text-xs text-blue-400 font-mono mb-1.5">
          <span>Algorithmic Benchmarking</span>
          <span aria-hidden="true">·</span>
          <span>Out-of-Sample Validation</span>
          <span aria-hidden="true">·</span>
          <span>302 Business Days</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Modeling Architecture & Out-of-Sample Validations
        </h2>
        <p className="text-sm text-slate-400 mt-1 max-w-3xl">
          Comparative empirical evaluation across 5 algorithmic paradigms tested against 302 out-of-sample trading days
          (July 2025 to October 2026). The Previous-Price Baseline serves as the hurdle rate.
        </p>
      </div>

      {/* Model Benchmark Performance Table */}
      <div className="bg-slate-900/90 rounded-2xl border border-slate-800 shadow-sm overflow-hidden">
        <div className="px-6 py-4 border-b border-slate-800 bg-slate-900/90 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Trophy className="w-4 h-4 text-amber-400" />
              Comparative Validation Error Metrics
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Ranked by Mean Absolute Error (MAE) across 302 out-of-sample business days.
            </p>
          </div>

          <button
            onClick={() => triggerDownload('metrics')}
            className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Metrics CSV</span>
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-slate-950 text-slate-400 uppercase border-b border-slate-800">
              <tr>
                <th className="py-3 px-4">Rank & Model</th>
                <th className="py-3 px-4">Algorithm Paradigm</th>
                <th className="py-3 px-4 text-right">MAE (¢/L)</th>
                <th className="py-3 px-4 text-right">RMSE (¢/L)</th>
                <th className="py-3 px-4 text-right">MedAE (¢/L)</th>
                <th className="py-3 px-4 text-right">RMSLE</th>
                <th className="py-3 px-4 text-right">95% CI Half-Width</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {MODEL_METRICS.map((m) => {
                const isWinner = m.rank === 1;
                return (
                  <tr
                    key={m.name}
                    className={`transition-colors ${
                      isWinner ? 'bg-emerald-950/20 text-white font-semibold' : 'hover:bg-slate-900/40'
                    }`}
                  >
                    <td className="py-3 px-4 flex items-center gap-2">
                      <span className={isWinner ? 'text-amber-400 font-bold' : 'text-slate-500'}>
                        #{m.rank}
                      </span>
                      <span className={isWinner ? 'text-emerald-400 font-bold' : 'text-white'}>
                        {m.name}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-400 font-sans">{m.type}</td>
                    <td className={`py-3 px-4 text-right tabular-nums ${isWinner ? 'text-emerald-400 font-bold' : ''}`}>
                      {m.mae.toFixed(3)}
                    </td>
                    <td className={`py-3 px-4 text-right tabular-nums ${isWinner ? 'text-emerald-400 font-bold' : ''}`}>
                      {m.rmse.toFixed(3)}
                    </td>
                    <td className="py-3 px-4 text-right tabular-nums">
                      {m.medae.toFixed(3)}
                    </td>
                    <td className="py-3 px-4 text-right tabular-nums">
                      {m.rmsle.toFixed(4)}
                    </td>
                    <td className="py-3 px-4 text-right tabular-nums text-cyan-400">
                      {m.ciWidth}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Analytical Takeaway Callout */}
        <div className="p-4 bg-slate-950 text-xs text-slate-300 border-t border-slate-800 flex items-start gap-2">
          <span className="text-cyan-400 font-bold">Key Insight:</span>
          <p className="leading-relaxed">
            <strong>Why Gradient Boosting Won (MAE = 1.742 ¢/L, RMSE = 2.884 ¢/L):</strong> While the simple persistence baseline
            achieves a slightly lower Median Absolute Error (0.60¢) on flat/decay days, it fails during asymmetric price cycle jumps,
            incurring massive 8¢–13¢ residual errors. Gradient Boosting's sequential tree boosting slashes RMSE by <strong>10.2%</strong> by
            leveraging 1-day momentum (<code>diff_1</code>) and 5-day volatility (<code>rolling_std_5</code>) to anticipate cycle spikes.
          </p>
        </div>
      </div>

      {/* Interactive Actual vs. Predicted Validation Visualizer */}
      <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-sm space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-bold text-white">
              Validation Set Trajectory: Actual vs. Model Predictions (October 2026 Sample)
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Select an algorithm below to overlay its predictions against true recorded Calgary prices.
            </p>
          </div>

          {/* Model Toggle Buttons */}
          <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-950 rounded-xl border border-slate-800">
            {Object.entries(modelLabels).map(([key, label]) => {
              const isActive = selectedModelKey === key;
              return (
                <button
                  key={key}
                  onClick={() => setSelectedModelKey(key as any)}
                  className={`px-3 py-1 text-xs rounded-lg font-medium transition-colors cursor-pointer whitespace-nowrap ${
                    isActive
                      ? 'bg-blue-600 text-white shadow-sm'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  {key === 'gradientBoosting' ? 'Gradient Boosting' : key === 'linearReg' ? 'Linear Reg' : key === 'baseline' ? 'Baseline' : key === 'randomForest' ? 'Random Forest' : 'Decision Tree'}
                </button>
              );
            })}
          </div>
        </div>

        {/* Scalable Vector Line Comparison Chart */}
        <div className="relative w-full overflow-x-auto">
          <svg
            viewBox={`0 0 ${chartWidth} ${chartHeight}`}
            className="w-full h-auto select-none max-h-72"
          >
            {/* Grid lines */}
            {[150, 155, 160, 165, 170].map((val) => {
              const y = getYPos(val);
              return (
                <g key={val}>
                  <line
                    x1={padX}
                    y1={y}
                    x2={chartWidth - padX}
                    y2={y}
                    stroke="#1e293b"
                    strokeDasharray="4 4"
                  />
                  <text
                    x={padX - 8}
                    y={y + 4}
                    fill="#64748b"
                    fontSize="10"
                    fontFamily="monospace"
                    textAnchor="end"
                  >
                    {val}¢
                  </text>
                </g>
              );
            })}

            {/* Actual Series (Solid Cyan Line) */}
            <polyline
              fill="none"
              stroke="#38bdf8"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
              points={actualPoints}
            />

            {/* Selected Model Series (Dashed Green/Amber Line) */}
            <polyline
              fill="none"
              stroke="#34d399"
              strokeWidth="2.5"
              strokeDasharray="4 4"
              strokeLinecap="round"
              strokeLinejoin="round"
              points={modelPoints}
            />

            {/* Actual Data Dots */}
            {VALIDATION_SAMPLE_SERIES.map((pt, i) => {
              const cx = getXPos(i, VALIDATION_SAMPLE_SERIES.length);
              const cyActual = getYPos(pt.actual);
              const cyModel = getYPos(pt[selectedModelKey]);
              return (
                <g key={i}>
                  <circle cx={cx} cy={cyActual} r="4" fill="#38bdf8" />
                  <circle cx={cx} cy={cyModel} r="4" fill="#34d399" />
                  {/* Date underneath */}
                  <text
                    x={cx}
                    y={chartHeight - 6}
                    fill="#94a3b8"
                    fontSize="9"
                    fontFamily="monospace"
                    textAnchor="middle"
                  >
                    {pt.date.slice(5)}
                  </text>
                </g>
              );
            })}
          </svg>
        </div>

        {/* Legend */}
        <div className="flex items-center justify-between text-xs pt-2 border-t border-slate-800/80">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5 text-slate-300">
              <span className="w-3 h-0.5 bg-cyan-400 inline-block" />
              <span>Actual Recorded Price</span>
            </span>
            <span className="flex items-center gap-1.5 text-emerald-300">
              <span className="w-3 h-0.5 bg-emerald-400 inline-block border-dashed border-b-2" />
              <span>{modelLabels[selectedModelKey]}</span>
            </span>
          </div>

          <span className="font-mono text-slate-400">Sample: Oct 12–23, 2026 Cycle Spike</span>
        </div>
      </div>

      {/* Model Selection Reasoning Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="p-5 bg-slate-900 rounded-xl border border-slate-800 space-y-2">
          <div className="text-xs font-mono font-bold text-cyan-400 uppercase">Model Justification</div>
          <h4 className="text-base font-bold text-white">Why These Algorithms Were Selected</h4>
          <div className="space-y-2 text-xs text-slate-400 leading-relaxed pt-1">
            <p>
              • <strong>Previous-Price Baseline:</strong> Crucial domain sanity check. Because 80% of days have price drift &lt; 0.5¢,
              any complex model that cannot beat yesterday's price adds negative practical business value.
            </p>
            <p>
              • <strong>Linear Regression:</strong> Direct autoregressive baseline (Y_t = β_0 + β_1 Y_t-1 + ...).
              Unique benefit: continuous slopes allow extrapolation if prices reach unprecedented all-time highs.
            </p>
            <p>
              • <strong>Decision Tree:</strong> Direct proxy for station operator threshold rules ("if margin drops below 2¢, spike +12¢").
            </p>
            <p>
              • <strong>Random Forest:</strong> Bagging decorrelated trees dampens single-station noise and daily pump fluctuations.
            </p>
            <p>
              • <strong>Gradient Boosting:</strong> Sequentially fits trees on prior residual errors, making it uniquely tuned to capture the hard-to-predict jump days.
            </p>
          </div>
        </div>

        <div className="p-5 bg-slate-900 rounded-xl border border-slate-800 space-y-2">
          <div className="text-xs font-mono font-bold text-emerald-400 uppercase">Recommended Alternatives</div>
          <h4 className="text-base font-bold text-white">Regularized & Robust Formulations</h4>
          <div className="space-y-2 text-xs text-slate-400 leading-relaxed pt-1">
            <p>
              • <strong>Ridge Regressor (L2 Regularization):</strong> Lags (Y_t-1, Y_t-2, rolling_mean) suffer from extreme multicollinearity
              (correlation &gt; 0.95). Ridge applies an L2 penalty that stabilizes coefficient inflation.
            </p>
            <p>
              • <strong>Huber Regressor:</strong> Uses a hybrid loss function that transitions from squared loss for small errors to linear loss for large errors.
              Prevents sudden 15¢ geopolitical shocks from overly distorting the regular decay slope.
            </p>
            <p>
              • <strong>LightGBM / XGBoost:</strong> High-performance gradient boosted decision trees with native histogram binning and built-in regularization.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
