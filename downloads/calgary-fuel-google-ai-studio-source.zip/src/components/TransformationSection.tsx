import React from 'react';
import { Layers, ShieldCheck, AlertCircle, ArrowRight } from 'lucide-react';
import { DATASET_STATS } from '../data/fuelData';

export const TransformationSection: React.FC = () => {
  return (
    <section id="transformation" className="space-y-8">
      {/* Header */}
      <div className="border-b border-slate-800/80 pb-6">
        <div className="flex items-center gap-2 text-xs text-emerald-400 font-mono mb-1.5">
          <span>Preprocessing Pipeline</span>
          <span aria-hidden="true">·</span>
          <span>DP3</span>
          <span aria-hidden="true">·</span>
          <span>Standardization & Train/Test Split</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Data Transformation & Chronological Train/Validation Partition
        </h2>
        <p className="text-sm text-slate-400 mt-1 max-w-3xl">
          Zero-leakage preprocessing methodology: chronological temporal splitting without shuffling,
          standardization via training set parameters only, and native target scale preservation.
        </p>
      </div>

      {/* Chronological Split Architecture */}
      <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-sm space-y-6">
        <div className="flex items-center justify-between">
          <h3 className="text-base font-bold text-white">
            Chronological 80/20 Train-Test Split (Zero Shuffling)
          </h3>
          <span className="text-xs font-mono text-cyan-400 px-2.5 py-1 rounded bg-slate-950 border border-slate-800">
            1,507 Usable Records
          </span>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed">
          Initial 10 warmup rows (Jan 1–15, 2021) are reserved to compute <code>lag_10</code>, leaving 1,507 contiguous records.
          The dataset is split chronologically into an earlier training partition and a later out-of-sample validation partition.
        </p>

        {/* Visual Split Timeline Bar */}
        <div className="space-y-2">
          <div className="w-full h-8 rounded-xl bg-slate-950 border border-slate-800 overflow-hidden flex font-mono text-xs font-bold text-center">
            <div
              className="bg-blue-600/40 text-blue-200 border-r border-blue-400/50 flex items-center justify-center transition-all"
              style={{ width: '80%' }}
            >
              <span>Training Set: 1,205 Days (80.0%)</span>
            </div>
            <div
              className="bg-emerald-600/40 text-emerald-200 flex items-center justify-center transition-all"
              style={{ width: '20%' }}
            >
              <span>Validation: 302 Days (20.0%)</span>
            </div>
          </div>

          <div className="flex justify-between text-[11px] font-mono text-slate-400">
            <span>2021-01-18 (Start)</span>
            <span className="text-white font-bold">Split Date: 2025-07-28</span>
            <span>2026-10-23 (End)</span>
          </div>
        </div>

        {/* Split Details Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-blue-400 font-bold font-mono">TRAINING PARTITION</span>
              <span className="font-mono text-slate-400">1,205 Records</span>
            </div>
            <div className="space-y-1 text-xs text-slate-300">
              <p>• <strong>Date Range:</strong> {DATASET_STATS.trainingRange}</p>
              <p>• <strong>Price Regimes Covered:</strong> 2021 post-pandemic recovery, 2022 historic surge (191.9¢), 2023 stabilization, 2024 seasonal cycles.</p>
              <p>• <strong>Role:</strong> Fits model weights and derives scaler parameters (μ_train, σ_train).</p>
            </div>
          </div>

          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="text-emerald-400 font-bold font-mono">OUT-OF-SAMPLE VALIDATION</span>
              <span className="font-mono text-slate-400">302 Records</span>
            </div>
            <div className="space-y-1 text-xs text-slate-300">
              <p>• <strong>Date Range:</strong> {DATASET_STATS.validationRange}</p>
              <p>• <strong>Price Regimes Covered:</strong> Late-2025 multi-year trough (104.2¢), Spring 2026 rapid rebound (189.9¢), Fall 2026 consolidation.</p>
              <p>• <strong>Role:</strong> Strict zero-leakage evaluation of generalized forecasting ability.</p>
            </div>
          </div>
        </div>

        {/* Shuffling Danger Callout */}
        <div className="p-4 bg-amber-950/20 border border-amber-500/30 rounded-xl flex items-start gap-3 text-xs">
          <AlertCircle className="w-4 h-4 text-amber-400 mt-0.5 shrink-0" />
          <div className="text-amber-200 leading-relaxed">
            <strong className="text-white block mb-0.5">Why Shuffling is Strictly Prohibited in Time Series:</strong>
            Random K-Fold cross-validation or random shuffling in financial time series destroys temporal structure.
            If shuffled, future data points (e.g. October 2026) are used to predict past prices (e.g. March 2021),
            causing massive lookahead data leakage that produces artificially flawless test scores that collapse in production.
          </div>
        </div>
      </div>

      {/* Scaling: Z-Score Standardization vs Min-Max Normalization */}
      <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-sm space-y-6">
        <h3 className="text-base font-bold text-white">
          Feature Scaling: Standardization (Z-Score) vs. Normalization (Min-Max)
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="p-5 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold text-emerald-400">
                Standardization (Z-Score) — SELECTED
              </span>
              <span className="text-[11px] font-mono text-slate-500">z = (x - μ) / σ</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Standardizes features to have zero mean (μ = 0) and unit variance (σ = 1).
            </p>
            <ul className="text-xs text-slate-400 space-y-1.5 list-disc list-inside">
              <li>
                <strong className="text-slate-300">Unbounded Range:</strong> Accommodates new multi-year market peaks or crashes
                without compressing or clipping values.
              </li>
              <li>
                <strong className="text-slate-300">Preserves Asymmetric Spikes:</strong> Sudden 10¢–15¢ cycle resets are preserved
                as high positive standard deviations without distorting everyday gradual price decay.
              </li>
              <li>
                <strong className="text-slate-300">Zero Leakage Architecture:</strong> The scaler is fit strictly on the training
                partition (μ_train, σ_train) and transformed onto validation data.
              </li>
            </ul>
          </div>

          <div className="p-5 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono font-bold text-rose-400">
                Min-Max Normalization — REJECTED
              </span>
              <span className="text-[11px] font-mono text-slate-500">x' = (x - x_min) / (x_max - x_min)</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">
              Scales feature values strictly between [0, 1].
            </p>
            <ul className="text-xs text-slate-400 space-y-1.5 list-disc list-inside">
              <li>
                <strong className="text-slate-300">Collapses on New Extremes:</strong> If gasoline prices in future validation
                break outside historical training bounds, normalized values exceed [0, 1] or truncate, causing model degradation.
              </li>
              <li>
                <strong className="text-slate-300">Compresses Volatility:</strong> A single historical spike compresses the subtle
                0.2¢ daily price erosions into an imperceptible micro-band.
              </li>
            </ul>
          </div>
        </div>

        {/* Target Scale Preservation */}
        <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 flex items-start gap-3 text-xs">
          <ShieldCheck className="w-4 h-4 text-cyan-400 mt-0.5 shrink-0" />
          <div className="text-slate-300 leading-relaxed">
            <strong className="text-white block mb-0.5">Target Scale Preservation (¢/L):</strong>
            While feature inputs ($X$) are standardized to stabilize gradient descent and tree split variance,
            the predicted target price ($y$) is maintained in its native <strong>cents per litre (¢/L)</strong>.
            This ensures error calculations (MAE, RMSE, MedAE), operational circuit breakers, and confidence intervals
            remain directly interpretable for business procurement without unscaling artifacts.
          </div>
        </div>
      </div>
    </section>
  );
};
