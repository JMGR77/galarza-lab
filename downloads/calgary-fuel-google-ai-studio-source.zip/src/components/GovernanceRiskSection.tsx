import React, { useState } from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  AlertOctagon,
  CheckSquare,
  Square,
  Lock,
  Activity,
  UserCheck,
  Zap,
} from 'lucide-react';

export const GovernanceRiskSection: React.FC = () => {
  const [checklist, setChecklist] = useState<Record<string, boolean>>({
    dq1: true,
    dq2: true,
    dl1: true,
    dl2: true,
    comp1: true,
    comp2: true,
    drift1: true,
    drift2: true,
    mon1: true,
    mon2: true,
    human1: true,
    human2: true,
  });

  const toggleItem = (id: string) => {
    setChecklist((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  return (
    <section id="governance" className="space-y-8">
      {/* Header */}
      <div className="border-b border-slate-800/80 pb-6">
        <div className="flex items-center gap-2 text-xs text-purple-400 font-mono mb-1.5">
          <span>AI Safety & Operational Controls</span>
          <span aria-hidden="true">·</span>
          <span>Governance Framework</span>
          <span aria-hidden="true">·</span>
          <span>Risk Mitigation</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          AI Governance Framework & Risk Mitigation
        </h2>
        <p className="text-sm text-slate-400 mt-1 max-w-3xl">
          Comprehensive production governance checklist, regulatory compliance under the Canadian Competition Act,
          and operational circuit breakers designed to safeguard automated procurement against market shocks.
        </p>
      </div>

      {/* The Key Risk Spotlight */}
      <div className="bg-gradient-to-b from-rose-950/30 to-slate-900/90 rounded-2xl border border-rose-500/30 p-6 shadow-sm space-y-5">
        <div className="flex items-center gap-2">
          <AlertOctagon className="w-5 h-5 text-rose-400 shrink-0" />
          <h3 className="text-base font-bold text-white">
            The Key Operational Risk: Model Blindness to Unscheduled External Shocks
          </h3>
        </div>

        <p className="text-xs text-slate-300 leading-relaxed">
          Because this machine learning engine relies exclusively on historical lag features ($t-1, t-2, \dots$),
          it possesses <strong>zero awareness of sudden real-world supply disruptions</strong>. An unscheduled shutdown
          at an Edmonton refinery supplying Calgary, a regional pipeline outage, a sudden geopolitical conflict, or an
          overnight provincial fuel tax change will cause retail prices to jump 10¢–15¢ in 24 hours without any prior warning in the lag data.
        </p>

        {/* 4-Pillar Circuit Breaker Protocol */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 pt-2">
          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-1.5">
            <div className="flex items-center gap-1.5 text-xs font-mono font-bold text-amber-400">
              <Zap className="w-3.5 h-3.5" />
              <span>1. Swing Alert Threshold</span>
            </div>
            <p className="text-xs text-slate-300 font-semibold">Mandatory Sign-off at ±4.0¢/L</p>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Whenever the model predicts a single-day net swing ≥ 4.0¢/L, automated purchasing triggers an alarm and halts execution until a human logistics supervisor approves.
            </p>
          </div>

          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-1.5">
            <div className="flex items-center gap-1.5 text-xs font-mono font-bold text-rose-400">
              <ShieldAlert className="w-3.5 h-3.5" />
              <span>2. Automated Kill-Switch</span>
            </div>
            <p className="text-xs text-slate-300 font-semibold">48h Pause if Deviation &gt; 5.0¢/L</p>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              If the actual recorded price on any day deviates from prediction by more than 5.0¢/L, automated ordering shuts down for 48 hours and reverts to spot cost-plus formulas.
            </p>
          </div>

          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-1.5">
            <div className="flex items-center gap-1.5 text-xs font-mono font-bold text-cyan-400">
              <Activity className="w-3.5 h-3.5" />
              <span>3. Rack Divergence Watch</span>
            </div>
            <p className="text-xs text-slate-300 font-semibold">Wholesale vs Retail Spread</p>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Continuously monitors the spread between Edmonton wholesale rack postings and Calgary retail boards. If rack prices jump &gt; 3.0¢, the retail forecast is flagged immediately.
            </p>
          </div>

          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-1.5">
            <div className="flex items-center gap-1.5 text-xs font-mono font-bold text-emerald-400">
              <Lock className="w-3.5 h-3.5" />
              <span>4. Regulatory Calendar</span>
            </div>
            <p className="text-xs text-slate-300 font-semibold">Deterministic Tax Injections</p>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              Scheduled policy dates (e.g., April 1 federal carbon tax resets or provincial fuel tax rate shifts) are hardcoded into the pipeline as deterministic price offsets.
            </p>
          </div>
        </div>
      </div>

      {/* Production Governance Checklist */}
      <div className="bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-sm space-y-5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <CheckSquare className="w-4 h-4 text-purple-400" />
              6-Pillar Production Governance Checklist
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Verified operational requirements for production deployment and enterprise compliance.
            </p>
          </div>

          <div className="text-xs font-mono text-cyan-400">
            {Object.values(checklist).filter(Boolean).length} / {Object.keys(checklist).length} Invariants Verified
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 pt-1">
          {/* Pillar 1 */}
          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
            <span className="text-xs font-mono font-bold text-cyan-400 block">
              01. Data Quality & Integrity
            </span>
            <div className="space-y-2 text-xs">
              <label
                onClick={() => toggleItem('dq1')}
                className="flex items-start gap-2.5 cursor-pointer text-slate-300 select-none"
              >
                {checklist.dq1 ? (
                  <CheckSquare className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                ) : (
                  <Square className="w-4 h-4 text-slate-600 shrink-0 mt-0.5" />
                )}
                <span>Plausibility boundary validation ($50 \le P \le 250$ ¢/L) on automated data ingestion.</span>
              </label>

              <label
                onClick={() => toggleItem('dq2')}
                className="flex items-start gap-2.5 cursor-pointer text-slate-300 select-none"
              >
                {checklist.dq2 ? (
                  <CheckSquare className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                ) : (
                  <Square className="w-4 h-4 text-slate-600 shrink-0 mt-0.5" />
                )}
                <span>Weekend exclusion rule: reject synthetic forward-filling or Saturday/Sunday interpolation.</span>
              </label>
            </div>
          </div>

          {/* Pillar 2 */}
          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
            <span className="text-xs font-mono font-bold text-blue-400 block">
              02. Data Leakage Prevention
            </span>
            <div className="space-y-2 text-xs">
              <label
                onClick={() => toggleItem('dl1')}
                className="flex items-start gap-2.5 cursor-pointer text-slate-300 select-none"
              >
                {checklist.dl1 ? (
                  <CheckSquare className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                ) : (
                  <Square className="w-4 h-4 text-slate-600 shrink-0 mt-0.5" />
                )}
                <span>Strict temporal causality: all engineered lags reference strictly $t-1$ and older.</span>
              </label>

              <label
                onClick={() => toggleItem('dl2')}
                className="flex items-start gap-2.5 cursor-pointer text-slate-300 select-none"
              >
                {checklist.dl2 ? (
                  <CheckSquare className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                ) : (
                  <Square className="w-4 h-4 text-slate-600 shrink-0 mt-0.5" />
                )}
                <span>Independent transformers: StandardScaler fit exclusively on the training partition.</span>
              </label>
            </div>
          </div>

          {/* Pillar 3 */}
          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
            <span className="text-xs font-mono font-bold text-emerald-400 block">
              03. Legal & Competition Act
            </span>
            <div className="space-y-2 text-xs">
              <label
                onClick={() => toggleItem('comp1')}
                className="flex items-start gap-2.5 cursor-pointer text-slate-300 select-none"
              >
                {checklist.comp1 ? (
                  <CheckSquare className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                ) : (
                  <Square className="w-4 h-4 text-slate-600 shrink-0 mt-0.5" />
                )}
                <span>Internal procurement only: strictly prohibited from sharing predictions with rival retailers.</span>
              </label>

              <label
                onClick={() => toggleItem('comp2')}
                className="flex items-start gap-2.5 cursor-pointer text-slate-300 select-none"
              >
                {checklist.comp2 ? (
                  <CheckSquare className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                ) : (
                  <Square className="w-4 h-4 text-slate-600 shrink-0 mt-0.5" />
                )}
                <span>Open-source licensing audit: verified permissible MIT/BSD dependencies (scikit-learn, joblib).</span>
              </label>
            </div>
          </div>

          {/* Pillar 4 */}
          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
            <span className="text-xs font-mono font-bold text-amber-400 block">
              04. Market & Concept Drift
            </span>
            <div className="space-y-2 text-xs">
              <label
                onClick={() => toggleItem('drift1')}
                className="flex items-start gap-2.5 cursor-pointer text-slate-300 select-none"
              >
                {checklist.drift1 ? (
                  <CheckSquare className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                ) : (
                  <Square className="w-4 h-4 text-slate-600 shrink-0 mt-0.5" />
                )}
                <span>Automated seasonal blend flags: bi-annual winter/summer transition alarms (April & October).</span>
              </label>

              <label
                onClick={() => toggleItem('drift2')}
                className="flex items-start gap-2.5 cursor-pointer text-slate-300 select-none"
              >
                {checklist.drift2 ? (
                  <CheckSquare className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                ) : (
                  <Square className="w-4 h-4 text-slate-600 shrink-0 mt-0.5" />
                )}
                <span>Unprecedented extreme alert: flag pipeline if price breaches 5-year maximum (191.9¢) or minimum (100.2¢).</span>
              </label>
            </div>
          </div>

          {/* Pillar 5 */}
          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
            <span className="text-xs font-mono font-bold text-purple-400 block">
              05. Production Monitoring
            </span>
            <div className="space-y-2 text-xs">
              <label
                onClick={() => toggleItem('mon1')}
                className="flex items-start gap-2.5 cursor-pointer text-slate-300 select-none"
              >
                {checklist.mon1 ? (
                  <CheckSquare className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                ) : (
                  <Square className="w-4 h-4 text-slate-600 shrink-0 mt-0.5" />
                )}
                <span>Continuous benchmark check: trigger engineering alert if rolling 7-day MAE exceeds baseline.</span>
              </label>

              <label
                onClick={() => toggleItem('mon2')}
                className="flex items-start gap-2.5 cursor-pointer text-slate-300 select-none"
              >
                {checklist.mon2 ? (
                  <CheckSquare className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                ) : (
                  <Square className="w-4 h-4 text-slate-600 shrink-0 mt-0.5" />
                )}
                <span>Retraining threshold: schedule automated model retraining if rolling 30-day MAE exceeds 2.5¢/L.</span>
              </label>
            </div>
          </div>

          {/* Pillar 6 */}
          <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
            <span className="text-xs font-mono font-bold text-rose-400 block">
              06. Human Review & Fallback
            </span>
            <div className="space-y-2 text-xs">
              <label
                onClick={() => toggleItem('human1')}
                className="flex items-start gap-2.5 cursor-pointer text-slate-300 select-none"
              >
                {checklist.human1 ? (
                  <CheckSquare className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                ) : (
                  <Square className="w-4 h-4 text-slate-600 shrink-0 mt-0.5" />
                )}
                <span>Dual-control authorization required on bulk tanker orders triggered by predicted swings &gt; 4.0¢.</span>
              </label>

              <label
                onClick={() => toggleItem('human2')}
                className="flex items-start gap-2.5 cursor-pointer text-slate-300 select-none"
              >
                {checklist.human2 ? (
                  <CheckSquare className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                ) : (
                  <Square className="w-4 h-4 text-slate-600 shrink-0 mt-0.5" />
                )}
                <span>Immutable audit trail logging every prediction, confidence interval, and manual override.</span>
              </label>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
