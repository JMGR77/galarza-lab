import React, { useState, useMemo } from 'react';
import {
  Calendar,
  Download,
  AlertTriangle,
  ShieldCheck,
  TrendingUp,
  TrendingDown,
  RefreshCw,
  Truck,
  Store,
  HelpCircle,
  Clock,
  Layers,
} from 'lucide-react';
import {
  DailyFuelRecord,
  HISTORICAL_PRESETS,
  getNextBusinessDay,
  formatBusinessDate,
  formatHumanDate,
  runGradientBoostingInference,
  triggerDownload,
} from '../data/fuelData';

export const PredictorSection: React.FC = () => {
  const [selectedPresetKey, setSelectedPresetKey] = useState<string>('2026-10-23');
  const [records, setRecords] = useState<DailyFuelRecord[]>(
    HISTORICAL_PRESETS['2026-10-23'].data
  );

  // Inferred next recorded business day (skips Saturday/Sunday)
  const targetDate = useMemo(() => {
    if (!records.length) return null;
    const latestDate = records[records.length - 1].date;
    return getNextBusinessDay(latestDate);
  }, [records]);

  // Price validation & parsing
  const prices = useMemo(() => {
    return records.map((r) => Number(r.price) || 0);
  }, [records]);

  const isValidInputs = useMemo(() => {
    return (
      records.length === 10 &&
      records.every(
        (r) =>
          r.date &&
          !isNaN(Number(r.price)) &&
          Number(r.price) >= 50 &&
          Number(r.price) <= 250
      )
    );
  }, [records]);

  // Model inference
  const inference = useMemo(() => {
    if (!isValidInputs) return null;
    const lastDate = records[records.length - 1].date;
    return runGradientBoostingInference(prices, lastDate);
  }, [prices, records, isValidInputs]);

  // Handlers
  const handlePresetChange = (key: string) => {
    setSelectedPresetKey(key);
    if (HISTORICAL_PRESETS[key]) {
      setRecords(HISTORICAL_PRESETS[key].data.map((d) => ({ ...d })));
    }
  };

  const handleRowChange = (index: number, field: 'date' | 'price', value: string) => {
    setRecords((prev) => {
      const updated = [...prev];
      if (field === 'price') {
        const num = parseFloat(value);
        updated[index] = { ...updated[index], price: isNaN(num) ? 0 : num };
      } else {
        updated[index] = { ...updated[index], date: value };
      }
      return updated;
    });
  };

  const handleResetToOct2026 = () => {
    setSelectedPresetKey('2026-10-23');
    setRecords(HISTORICAL_PRESETS['2026-10-23'].data.map((d) => ({ ...d })));
  };

  const handleClear = () => {
    setSelectedPresetKey('custom');
    const emptyRows: DailyFuelRecord[] = Array.from({ length: 10 }, (_, i) => ({
      date: '',
      price: 150.0,
    }));
    setRecords(emptyRows);
  };

  // SVG Chart Dimensions
  const chartHeight = 220;
  const chartWidth = 640;
  const paddingX = 45;
  const paddingY = 25;

  const chartPrices = useMemo(() => {
    if (!inference) return prices;
    return [...prices, inference.predictedPrice];
  }, [prices, inference]);

  const minChartP = useMemo(() => {
    const minVal = Math.min(...chartPrices, inference ? inference.ciLower : 100);
    return Math.floor(minVal - 3);
  }, [chartPrices, inference]);

  const maxChartP = useMemo(() => {
    const maxVal = Math.max(...chartPrices, inference ? inference.ciUpper : 200);
    return Math.ceil(maxVal + 3);
  }, [chartPrices, inference]);

  const getYPos = (val: number) => {
    const range = maxChartP - minChartP || 1;
    const normalized = (val - minChartP) / range;
    return chartHeight - paddingY - normalized * (chartHeight - paddingY * 2);
  };

  const getXPos = (index: number) => {
    const totalPoints = 11; // 10 past points + 1 predicted
    return paddingX + (index / (totalPoints - 1)) * (chartWidth - paddingX * 2);
  };

  return (
    <section id="deployment" className="space-y-8">
      {/* Header and Context Banner */}
      <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-slate-800/80 pb-6">
        <div>
          <div className="flex items-center gap-2 text-xs text-cyan-400 font-mono mb-1.5">
            <span>Production Deployment</span>
            <span aria-hidden="true">·</span>
            <span>Gradient Boosting Architecture</span>
            <span aria-hidden="true">·</span>
            <span>95% Confidence Intervals</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Next-Recorded-Day Calgary Gasoline Price Forecaster
          </h1>
          <p className="text-sm text-slate-400 mt-1 max-w-3xl">
            Input or modify dated past fuel prices (t-10 to t-1). The engine computes engineered lag features,
            advances to the next recorded business day, evaluates the operational circuit breaker, and renders
            calibrated 95% confidence intervals.
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={() => triggerDownload('audit_report')}
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download Audit Report</span>
          </button>
        </div>
      </div>

      {/* Main Two-Column App Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Left Column: 10-Day Historical Input Form */}
        <div className="lg:col-span-7 bg-slate-900/90 rounded-2xl border border-slate-800 p-6 shadow-sm space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <h2 className="text-base font-bold text-white flex items-center gap-2">
                <Clock className="w-4 h-4 text-cyan-400" />
                Historical Recorded Window (t-10 to t-1)
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Edit prices and dates freely. The model automatically skips weekends for the next business day.
              </p>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleResetToOct2026}
                className="text-xs px-2.5 py-1.5 rounded-lg bg-blue-600/20 text-cyan-300 border border-blue-500/30 hover:bg-blue-600/30 transition-colors cursor-pointer flex items-center gap-1"
              >
                <RefreshCw className="w-3 h-3" />
                Oct 2026 Latest
              </button>
              <button
                onClick={handleClear}
                className="text-xs px-2.5 py-1.5 rounded-lg bg-slate-950 text-slate-400 border border-slate-800 hover:text-slate-200 transition-colors cursor-pointer"
              >
                Clear
              </button>
            </div>
          </div>

          {/* Preset Selector */}
          <div className="p-3 bg-slate-950 rounded-xl border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <label className="text-xs text-slate-300 font-medium">Load Historical Scenario Preset:</label>
            <select
              value={selectedPresetKey}
              onChange={(e) => handlePresetChange(e.target.value)}
              className="bg-slate-900 text-xs font-mono text-cyan-300 border border-slate-700 rounded-lg px-2.5 py-1.5 focus:outline-none focus:border-blue-500 cursor-pointer"
            >
              {Object.entries(HISTORICAL_PRESETS).map(([key, item]) => (
                <option key={key} value={key}>
                  {item.label}
                </option>
              ))}
            </select>
          </div>

          {/* Editable 10-Row Table */}
          <div className="border border-slate-800 rounded-xl overflow-hidden bg-slate-950">
            <div className="max-h-80 overflow-y-auto">
              <table className="w-full text-left text-xs font-mono">
                <thead className="bg-slate-900/90 text-slate-400 border-b border-slate-800 sticky top-0 z-10">
                  <tr>
                    <th className="py-2.5 px-3">Lag Position</th>
                    <th className="py-2.5 px-3">Recorded Date</th>
                    <th className="py-2.5 px-3 text-right">Price (¢/L)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60">
                  {records.map((r, idx) => {
                    const lagNumber = 10 - idx;
                    const isAnchor = lagNumber === 1;
                    return (
                      <tr
                        key={idx}
                        className={`transition-colors ${
                          isAnchor ? 'bg-blue-950/20' : 'hover:bg-slate-900/40'
                        }`}
                      >
                        <td className="py-2 px-3 text-slate-400">
                          <span className={isAnchor ? 'text-cyan-400 font-bold' : ''}>
                            t - {lagNumber} {isAnchor ? '(Anchor)' : ''}
                          </span>
                        </td>
                        <td className="py-2 px-3">
                          <input
                            type="date"
                            value={r.date}
                            onChange={(e) => handleRowChange(idx, 'date', e.target.value)}
                            className="bg-slate-900 text-slate-200 border border-slate-700 rounded px-2 py-1 text-xs font-mono focus:border-blue-500 focus:outline-none w-36"
                          />
                        </td>
                        <td className="py-2 px-3 text-right">
                          <div className="flex items-center justify-end gap-1.5">
                            <input
                              type="number"
                              step="0.1"
                              min="50"
                              max="250"
                              value={r.price}
                              onChange={(e) => handleRowChange(idx, 'price', e.target.value)}
                              className="bg-slate-900 text-white font-bold border border-slate-700 rounded px-2 py-1 text-xs font-mono text-right focus:border-blue-500 focus:outline-none w-24"
                            />
                            <span className="text-slate-500 text-[11px]">¢</span>
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Inferred Target Business Day Notice */}
          <div className="p-3.5 bg-slate-950 rounded-xl border border-slate-800 flex items-center justify-between text-xs">
            <div className="flex items-center gap-2 text-slate-400">
              <Calendar className="w-4 h-4 text-cyan-400" />
              <span>Target Inferred Horizon:</span>
            </div>
            <div className="font-mono font-bold text-white bg-slate-900 px-2.5 py-1 rounded border border-slate-800">
              {targetDate ? formatHumanDate(targetDate) : 'Select a valid date'}
            </div>
          </div>
        </div>

        {/* Right Column: Prediction Engine & Confidence Intervals */}
        <div className="lg:col-span-5 space-y-6">
          {inference ? (
            <div className="bg-gradient-to-b from-slate-900 to-slate-950 rounded-2xl border border-slate-800 p-6 shadow-sm space-y-5">
              {/* Circuit Breaker Status Banner */}
              <div className="flex items-center justify-between">
                <div className="text-xs font-mono text-cyan-400 font-semibold uppercase tracking-wider">
                  Model Output
                </div>
                {inference.circuitBreakerTriggered ? (
                  <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-rose-500/10 text-rose-400 border border-rose-500/30 text-[11px] font-mono font-bold">
                    <AlertTriangle className="w-3 h-3" />
                    <span>CIRCUIT BREAKER: TRIGGERED</span>
                  </div>
                ) : inference.circuitBreakerLevel === 'ELEVATED' ? (
                  <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/30 text-[11px] font-mono font-bold">
                    <AlertTriangle className="w-3 h-3" />
                    <span>VOLATILITY: ELEVATED</span>
                  </div>
                ) : (
                  <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-[11px] font-mono font-bold">
                    <ShieldCheck className="w-3 h-3" />
                    <span>CIRCUIT BREAKER: NORMAL</span>
                  </div>
                )}
              </div>

              {/* Main Point Forecast */}
              <div>
                <p className="text-xs text-slate-400">
                  Predicted Next-Recorded-Day Price (
                  <span className="font-mono text-slate-200">
                    {targetDate ? formatBusinessDate(targetDate) : 'Next Day'}
                  </span>
                  )
                </p>
                <div className="flex items-baseline gap-2 mt-1.5">
                  <span className="text-5xl font-extrabold text-white font-mono tracking-tight tabular-nums">
                    {inference.predictedPrice.toFixed(1)}
                  </span>
                  <span className="text-xl font-bold text-slate-400 font-mono">¢/L</span>
                  <div
                    className={`ml-3 inline-flex items-center gap-1 text-xs font-mono font-semibold ${
                      inference.deltaPrice >= 0 ? 'text-emerald-400' : 'text-cyan-400'
                    }`}
                  >
                    {inference.deltaPrice >= 0 ? (
                      <TrendingUp className="w-3.5 h-3.5" />
                    ) : (
                      <TrendingDown className="w-3.5 h-3.5" />
                    )}
                    <span>
                      {inference.deltaPrice >= 0 ? '+' : ''}
                      {inference.deltaPrice.toFixed(1)} ¢/L vs yesterday
                    </span>
                  </div>
                </div>
              </div>

              {/* 95% Confidence Interval Card */}
              <div className="p-4 bg-slate-950 rounded-xl border border-slate-800 space-y-3">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-slate-400 font-medium">95% Confidence Band (± 1.96 × RMSE):</span>
                  <span className="font-mono text-cyan-400 font-bold tabular-nums">
                    [{inference.ciLower.toFixed(1)} , {inference.ciUpper.toFixed(1)}] ¢/L
                  </span>
                </div>

                {/* Visual Confidence Bar */}
                <div className="w-full bg-slate-900 h-3 rounded-full relative overflow-hidden">
                  <div
                    className="absolute inset-y-0 bg-gradient-to-r from-cyan-500/30 via-blue-500 to-cyan-500/30 rounded-full"
                    style={{ left: '15%', right: '15%' }}
                  />
                  {/* Marker for point forecast */}
                  <div
                    className="absolute top-0 bottom-0 w-1.5 bg-white rounded-full shadow"
                    style={{ left: '50%', transform: 'translateX(-50%)' }}
                  />
                </div>

                <div className="flex justify-between text-[11px] text-slate-400 font-mono">
                  <span>Lower: {inference.ciLower.toFixed(1)} ¢</span>
                  <span className="text-slate-500">Margin: ±5.65 ¢/L</span>
                  <span>Upper: {inference.ciUpper.toFixed(1)} ¢</span>
                </div>
              </div>

              {/* Computed Feature Metrics */}
              <div className="pt-2 border-t border-slate-800/80 space-y-2 text-xs">
                <div className="flex justify-between text-slate-400">
                  <span>Previous-Day Anchor (lag_1):</span>
                  <span className="font-mono text-white tabular-nums">
                    {inference.baselinePrice.toFixed(1)} ¢/L
                  </span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>1-Day Velocity (diff_1):</span>
                  <span className="font-mono text-slate-300 tabular-nums">
                    {inference.features.diff_1 >= 0 ? '+' : ''}
                    {inference.features.diff_1.toFixed(1)} ¢/L
                  </span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>5-Day Moving Average (rolling_mean_5):</span>
                  <span className="font-mono text-slate-300 tabular-nums">
                    {inference.features.rolling_mean_5.toFixed(2)} ¢/L
                  </span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>5-Day Rolling Volatility (rolling_std_5):</span>
                  <span className="font-mono text-slate-300 tabular-nums">
                    {inference.features.rolling_std_5.toFixed(2)} ¢/L
                  </span>
                </div>
                <div className="flex justify-between text-slate-400">
                  <span>5-Day Net Trajectory (diff_5):</span>
                  <span className="font-mono text-slate-300 tabular-nums">
                    {inference.features.diff_5 >= 0 ? '+' : ''}
                    {inference.features.diff_5.toFixed(1)} ¢/L
                  </span>
                </div>
              </div>

              {/* Operational Decision Directives */}
              <div
                className={`p-4 rounded-xl border space-y-3 ${
                  inference.circuitBreakerTriggered
                    ? 'bg-rose-950/20 border-rose-500/30 text-rose-200'
                    : 'bg-blue-950/20 border-blue-500/30 text-blue-200'
                }`}
              >
                <div className="text-xs font-bold uppercase tracking-wider flex items-center gap-1.5">
                  <span>⚡</span>
                  <span>{inference.directive.headline}</span>
                </div>

                <div className="space-y-2 text-xs text-slate-300">
                  <div className="flex items-start gap-2">
                    <Truck className="w-3.5 h-3.5 text-cyan-400 mt-0.5 shrink-0" />
                    <div>
                      <strong className="text-white">Fleet Manager:</strong>{' '}
                      {inference.directive.fleetAction}
                    </div>
                  </div>
                  <div className="flex items-start gap-2">
                    <Store className="w-3.5 h-3.5 text-cyan-400 mt-0.5 shrink-0" />
                    <div>
                      <strong className="text-white">Fuel Retailer:</strong>{' '}
                      {inference.directive.retailAction}
                    </div>
                  </div>
                </div>

                <p className="text-[11px] text-slate-400 border-t border-slate-800/80 pt-2 leading-relaxed">
                  <strong>Risk Note:</strong> {inference.directive.rationale}
                </p>
              </div>
            </div>
          ) : (
            <div className="p-8 bg-slate-900 rounded-2xl border border-slate-800 text-center">
              <AlertTriangle className="w-8 h-8 text-amber-400 mx-auto mb-2" />
              <h3 className="text-sm font-bold text-white">Invalid Inputs</h3>
              <p className="text-xs text-slate-400 mt-1">
                Please ensure all 10 price fields are numeric values between 50¢ and 250¢/L.
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Interactive Horizon Forecast Chart with Confidence Band */}
      {inference && (
        <div className="bg-slate-900/80 rounded-2xl border border-slate-800 p-6 shadow-sm space-y-4">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <h3 className="text-base font-bold text-white">
                Rolling 10-Day Historical Window with Projected Next-Day Interval
              </h3>
              <p className="text-xs text-slate-400 mt-0.5">
                Visualizing the actual past business days (t-10 to t-1), the point forecast, and the 95% confidence cone.
              </p>
            </div>

            <div className="flex items-center gap-4 text-xs font-mono">
              <span className="flex items-center gap-1.5 text-slate-300">
                <span className="w-3 h-0.5 bg-blue-400 inline-block" />
                <span>Recorded History</span>
              </span>
              <span className="flex items-center gap-1.5 text-cyan-300">
                <span className="w-3 h-0.5 bg-cyan-400 inline-block border-dashed border-b-2" />
                <span>Point Forecast</span>
              </span>
              <span className="flex items-center gap-1.5 text-cyan-400">
                <span className="w-3 h-2 bg-cyan-500/20 border border-cyan-500/40 inline-block" />
                <span>95% CI Range</span>
              </span>
            </div>
          </div>

          {/* Clean Vector SVG Chart */}
          <div className="relative w-full overflow-x-auto">
            <svg
              viewBox={`0 0 ${chartWidth} ${chartHeight}`}
              className="w-full h-auto max-h-72 select-none"
            >
              {/* Grid Lines */}
              {[minChartP, (minChartP + maxChartP) / 2, maxChartP].map((val, idx) => {
                const y = getYPos(val);
                return (
                  <g key={idx}>
                    <line
                      x1={paddingX}
                      y1={y}
                      x2={chartWidth - paddingX}
                      y2={y}
                      stroke="#1e293b"
                      strokeDasharray="4 4"
                    />
                    <text
                      x={paddingX - 8}
                      y={y + 4}
                      fill="#64748b"
                      fontSize="10"
                      fontFamily="monospace"
                      textAnchor="end"
                    >
                      {val.toFixed(0)}¢
                    </text>
                  </g>
                );
              })}

              {/* Shaded 95% Confidence Cone Polygon */}
              {(() => {
                const xAnchor = getXPos(9);
                const yAnchor = getYPos(prices[9]);
                const xPred = getXPos(10);
                const yUpper = getYPos(inference.ciUpper);
                const yLower = getYPos(inference.ciLower);

                const polygonPoints = `${xAnchor},${yAnchor} ${xPred},${yUpper} ${xPred},${yLower}`;
                return (
                  <polygon
                    points={polygonPoints}
                    fill="rgba(34, 211, 238, 0.18)"
                    stroke="rgba(34, 211, 238, 0.4)"
                    strokeWidth="1"
                  />
                );
              })()}

              {/* Historical Line Segments */}
              {(() => {
                const points = prices.map((p, i) => `${getXPos(i)},${getYPos(p)}`).join(' ');
                return (
                  <polyline
                    fill="none"
                    stroke="#38bdf8"
                    strokeWidth="2.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    points={points}
                  />
                );
              })()}

              {/* Forecast Dashed Line Segment (from t-1 to predicted target) */}
              {(() => {
                const x1 = getXPos(9);
                const y1 = getYPos(prices[9]);
                const x2 = getXPos(10);
                const y2 = getYPos(inference.predictedPrice);
                return (
                  <line
                    x1={x1}
                    y1={y1}
                    x2={x2}
                    y2={y2}
                    stroke="#22d3ee"
                    strokeWidth="2.5"
                    strokeDasharray="4 4"
                  />
                );
              })()}

              {/* Historical Data Dots */}
              {prices.map((p, i) => {
                const cx = getXPos(i);
                const cy = getYPos(p);
                return (
                  <g key={i}>
                    <circle cx={cx} cy={cy} r="3.5" fill="#38bdf8" />
                    {/* Date label underneath */}
                    <text
                      x={cx}
                      y={chartHeight - 8}
                      fill="#94a3b8"
                      fontSize="9"
                      fontFamily="monospace"
                      textAnchor="middle"
                    >
                      {records[i]?.date ? records[i].date.slice(5) : `t-${10 - i}`}
                    </text>
                  </g>
                );
              })}

              {/* Forecast Point Marker */}
              {(() => {
                const cx = getXPos(10);
                const cy = getYPos(inference.predictedPrice);
                return (
                  <g>
                    <circle
                      cx={cx}
                      cy={cy}
                      r="6"
                      fill="#22d3ee"
                      stroke="#0f172a"
                      strokeWidth="2"
                    />
                    <text
                      x={cx}
                      y={cy - 10}
                      fill="#22d3ee"
                      fontSize="10"
                      fontWeight="bold"
                      fontFamily="monospace"
                      textAnchor="middle"
                    >
                      {inference.predictedPrice.toFixed(1)}¢
                    </text>
                    <text
                      x={cx}
                      y={chartHeight - 8}
                      fill="#22d3ee"
                      fontSize="9"
                      fontWeight="bold"
                      fontFamily="monospace"
                      textAnchor="middle"
                    >
                      Target
                    </text>
                  </g>
                );
              })()}
            </svg>
          </div>
        </div>
      )}
    </section>
  );
};
