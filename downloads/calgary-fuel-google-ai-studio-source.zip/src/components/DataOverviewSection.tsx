import React, { useState } from 'react';
import {
  BarChart3,
  Calendar,
  Layers,
  Sparkles,
  ArrowUpRight,
  ArrowDownRight,
  Info,
} from 'lucide-react';
import { DATASET_STATS, MACRO_TIMELINE_SERIES } from '../data/fuelData';

export const DataOverviewSection: React.FC = () => {
  const [hoveredPoint, setHoveredPoint] = useState<{ date: string; price: number } | null>(null);

  // SVG Chart Dimensions
  const chartHeight = 260;
  const chartWidth = 900;
  const padX = 50;
  const padY = 30;

  const minP = 95;
  const maxP = 200;

  const getYPos = (val: number) => {
    const norm = (val - minP) / (maxP - minP);
    return chartHeight - padY - norm * (chartHeight - padY * 2);
  };

  const getXPos = (idx: number, total: number) => {
    return padX + (idx / (total - 1)) * (chartWidth - padX * 2);
  };

  const pointsString = MACRO_TIMELINE_SERIES.map((pt, i) =>
    `${getXPos(i, MACRO_TIMELINE_SERIES.length)},${getYPos(pt.price)}`
  ).join(' ');

  return (
    <section id="overview" className="space-y-8">
      {/* Header */}
      <div className="border-b border-slate-800/80 pb-6">
        <div className="flex items-center gap-2 text-xs text-blue-400 font-mono mb-1.5">
          <span>Exploratory Data Analysis</span>
          <span aria-hidden="true">·</span>
          <span>5-Year Calgary Retail Gas Dataset</span>
          <span aria-hidden="true">·</span>
          <span>1,517 Business Days</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Calgary Fuel Price Dataset Overview (2021–2026)
        </h2>
        <p className="text-sm text-slate-400 mt-1 max-w-3xl">
          Complete statistical breakdown of 1,517 daily retail unleaded regular gasoline observations in Calgary.
          The dataset follows a business-day trading schedule with 0 missing values, capturing major macroeconomic
          cycles and local forecourt price wars.
        </p>
      </div>

      {/* Summary KPI Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
        <div className="p-3.5 bg-slate-900/90 rounded-xl border border-slate-800">
          <p className="text-[11px] text-slate-400 font-mono uppercase">Observations</p>
          <p className="text-lg font-bold text-white font-mono mt-1 tabular-nums">
            {DATASET_STATS.totalRows.toLocaleString()}
          </p>
          <p className="text-[10px] text-slate-500 mt-0.5">Business Days</p>
        </div>

        <div className="p-3.5 bg-slate-900/90 rounded-xl border border-slate-800">
          <p className="text-[11px] text-slate-400 font-mono uppercase">Mean Price</p>
          <p className="text-lg font-bold text-cyan-400 font-mono mt-1 tabular-nums">
            {DATASET_STATS.meanPrice.toFixed(1)} ¢
          </p>
          <p className="text-[10px] text-slate-500 mt-0.5">Average Level</p>
        </div>

        <div className="p-3.5 bg-slate-900/90 rounded-xl border border-slate-800">
          <p className="text-[11px] text-slate-400 font-mono uppercase">Std Deviation</p>
          <p className="text-lg font-bold text-white font-mono mt-1 tabular-nums">
            {DATASET_STATS.stdDev.toFixed(1)} ¢
          </p>
          <p className="text-[10px] text-slate-500 mt-0.5">Volatility</p>
        </div>

        <div className="p-3.5 bg-slate-900/90 rounded-xl border border-slate-800">
          <p className="text-[11px] text-slate-400 font-mono uppercase">All-Time Min</p>
          <p className="text-lg font-bold text-emerald-400 font-mono mt-1 tabular-nums">
            {DATASET_STATS.minPrice.toFixed(1)} ¢
          </p>
          <p className="text-[10px] text-slate-500 mt-0.5">Jan 19, 2021</p>
        </div>

        <div className="p-3.5 bg-slate-900/90 rounded-xl border border-slate-800">
          <p className="text-[11px] text-slate-400 font-mono uppercase">25th Percentile</p>
          <p className="text-lg font-bold text-white font-mono mt-1 tabular-nums">
            {DATASET_STATS.p25.toFixed(1)} ¢
          </p>
          <p className="text-[10px] text-slate-500 mt-0.5">First Quartile</p>
        </div>

        <div className="p-3.5 bg-slate-900/90 rounded-xl border border-slate-800">
          <p className="text-[11px] text-slate-400 font-mono uppercase">Median (50%)</p>
          <p className="text-lg font-bold text-white font-mono mt-1 tabular-nums">
            {DATASET_STATS.p50.toFixed(1)} ¢
          </p>
          <p className="text-[10px] text-slate-500 mt-0.5">Midpoint Price</p>
        </div>

        <div className="p-3.5 bg-slate-900/90 rounded-xl border border-slate-800">
          <p className="text-[11px] text-slate-400 font-mono uppercase">75th Percentile</p>
          <p className="text-lg font-bold text-white font-mono mt-1 tabular-nums">
            {DATASET_STATS.p75.toFixed(1)} ¢
          </p>
          <p className="text-[10px] text-slate-500 mt-0.5">Third Quartile</p>
        </div>

        <div className="p-3.5 bg-slate-900/90 rounded-xl border border-slate-800">
          <p className="text-[11px] text-slate-400 font-mono uppercase">All-Time Max</p>
          <p className="text-lg font-bold text-rose-400 font-mono mt-1 tabular-nums">
            {DATASET_STATS.maxPrice.toFixed(1)} ¢
          </p>
          <p className="text-[10px] text-slate-500 mt-0.5">June 2022</p>
        </div>
      </div>

      {/* 5-Year Historical Trajectory Interactive Chart */}
      <div className="p-6 bg-slate-900/80 rounded-2xl border border-slate-800 shadow-sm space-y-4">
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h3 className="text-base font-bold text-white">
              Calgary Unleaded Retail Price Trajectory (2021 – 2026)
            </h3>
            <p className="text-xs text-slate-400 mt-0.5">
              Hover over points to inspect specific historical dates and recorded prices (¢/L).
            </p>
          </div>

          <div className="flex items-center gap-4 text-xs font-mono">
            {hoveredPoint ? (
              <span className="text-cyan-400 bg-slate-950 px-2.5 py-1 rounded border border-slate-800 font-bold">
                {hoveredPoint.date}: {hoveredPoint.price.toFixed(1)} ¢/L
              </span>
            ) : (
              <span className="text-slate-500">Hover points to inspect</span>
            )}
            <span className="text-slate-400">Unit: Cents per Litre (¢/L)</span>
          </div>
        </div>

        {/* Scalable Vector Line Chart */}
        <div className="relative w-full overflow-x-auto">
          <svg
            viewBox={`0 0 ${chartWidth} ${chartHeight}`}
            className="w-full h-auto select-none max-h-80"
          >
            {/* Horizontal Grid lines */}
            {[100, 125, 150, 175, 200].map((val) => {
              const y = getYPos(val);
              return (
                <g key={val}>
                  <line
                    x1={padX}
                    y1={y}
                    x2={chartWidth - padX}
                    y2={y}
                    stroke="#1e293b"
                    strokeDasharray="4 4"
                  />
                  <text
                    x={padX - 8}
                    y={y + 4}
                    fill="#64748b"
                    fontSize="10"
                    fontFamily="monospace"
                    textAnchor="end"
                  >
                    {val}¢
                  </text>
                </g>
              );
            })}

            {/* Area Gradient fill */}
            <defs>
              <linearGradient id="areaGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#38bdf8" stopOpacity="0.25" />
                <stop offset="100%" stopColor="#38bdf8" stopOpacity="0.0" />
              </linearGradient>
            </defs>

            {/* Filled Area */}
            {(() => {
              const firstX = getXPos(0, MACRO_TIMELINE_SERIES.length);
              const lastX = getXPos(
                MACRO_TIMELINE_SERIES.length - 1,
                MACRO_TIMELINE_SERIES.length
              );
              const bottomY = getYPos(minP);
              const areaPath = `M ${firstX},${bottomY} L ${pointsString.split(' ').join(' L ')} L ${lastX},${bottomY} Z`;
              return <path d={areaPath} fill="url(#areaGradient)" />;
            })()}

            {/* Historical Series Line */}
            <polyline
              fill="none"
              stroke="#38bdf8"
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
              points={pointsString}
            />

            {/* Key Milestone Annotations */}
            {/* 2021 Low: 100.2 */}
            <g>
              <line x1={getXPos(1, MACRO_TIMELINE_SERIES.length)} y1={getYPos(100.2)} x2={getXPos(1, MACRO_TIMELINE_SERIES.length)} y2={getYPos(100.2) + 20} stroke="#10b981" strokeWidth="1.5" />
              <text x={getXPos(1, MACRO_TIMELINE_SERIES.length)} y={getYPos(100.2) + 30} fill="#10b981" fontSize="9" fontFamily="monospace" textAnchor="middle">
                100.2¢ Low
              </text>
            </g>

            {/* 2022 High: 191.9 */}
            <g>
              <line x1={getXPos(8, MACRO_TIMELINE_SERIES.length)} y1={getYPos(191.9)} x2={getXPos(8, MACRO_TIMELINE_SERIES.length)} y2={getYPos(191.9) - 15} stroke="#f43f5e" strokeWidth="1.5" />
              <text x={getXPos(8, MACRO_TIMELINE_SERIES.length)} y={getYPos(191.9) - 20} fill="#f43f5e" fontSize="9" fontWeight="bold" fontFamily="monospace" textAnchor="middle">
                191.9¢ All-Time Peak
              </text>
            </g>

            {/* 2025 Low: 104.2 */}
            <g>
              <line x1={getXPos(26, MACRO_TIMELINE_SERIES.length)} y1={getYPos(104.2)} x2={getXPos(26, MACRO_TIMELINE_SERIES.length)} y2={getYPos(104.2) + 20} stroke="#10b981" strokeWidth="1.5" />
              <text x={getXPos(26, MACRO_TIMELINE_SERIES.length)} y={getYPos(104.2) + 30} fill="#10b981" fontSize="9" fontFamily="monospace" textAnchor="middle">
                104.2¢ Low
              </text>
            </g>

            {/* Interactive Dots */}
            {MACRO_TIMELINE_SERIES.map((pt, i) => {
              const cx = getXPos(i, MACRO_TIMELINE_SERIES.length);
              const cy = getYPos(pt.price);
              const isHovered = hoveredPoint?.date === pt.date;
              return (
                <circle
                  key={i}
                  cx={cx}
                  cy={cy}
                  r={isHovered ? 6 : 3}
                  fill={isHovered ? '#ffffff' : '#38bdf8'}
                  stroke={isHovered ? '#0284c7' : 'none'}
                  strokeWidth="2"
                  className="cursor-pointer transition-all"
                  onMouseEnter={() => setHoveredPoint(pt)}
                  onMouseLeave={() => setHoveredPoint(null)}
                />
              );
            })}

            {/* Year Labels along the X-Axis */}
            {[
              { year: '2021', idx: 0 },
              { year: '2022', idx: 6 },
              { year: '2023', idx: 12 },
              { year: '2024', idx: 17 },
              { year: '2025', idx: 22 },
              { year: '2026', idx: 27 },
            ].map((yItem) => (
              <text
                key={yItem.year}
                x={getXPos(yItem.idx, MACRO_TIMELINE_SERIES.length)}
                y={chartHeight - 8}
                fill="#94a3b8"
                fontSize="10"
                fontFamily="monospace"
                textAnchor="middle"
              >
                {yItem.year}
              </text>
            ))}
          </svg>
        </div>
      </div>

      {/* Domain Patterns Explanation Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="p-5 bg-slate-900 rounded-xl border border-slate-800 space-y-2">
          <div className="flex items-center gap-2 text-cyan-400 font-mono text-xs font-semibold">
            <span>Pattern 01</span>
            <span aria-hidden="true">·</span>
            <span>Seasonality</span>
          </div>
          <h4 className="text-base font-bold text-white">Summer vs. Winter Fuel Blend Shifts</h4>
          <p className="text-xs text-slate-400 leading-relaxed">
            Refineries switch to summer-blend gasoline in April (low Reid Vapor Pressure, higher butane extraction costs),
            coinciding with surging spring driving demand. In October, refineries switch back to cheaper winter blends.
            This creates a recurring 10¢–20¢ seasonal swing independent of crude oil prices.
          </p>
        </div>

        <div className="p-5 bg-slate-900 rounded-xl border border-slate-800 space-y-2">
          <div className="flex items-center gap-2 text-emerald-400 font-mono text-xs font-semibold">
            <span>Pattern 02</span>
            <span aria-hidden="true">·</span>
            <span>Micro-Economics</span>
          </div>
          <h4 className="text-base font-bold text-white">The Asymmetric "Sawtooth" Cycle</h4>
          <p className="text-xs text-slate-400 leading-relaxed">
            Calgary gas stations do not adjust prices smoothly. Stations engage in aggressive price competition,
            shaving 0.2¢–0.5¢ per day over 5 to 10 days until retail margins turn negative. Then, a major retail brand
            triggers a rapid <strong>+5¢ to +15¢ restoration spike in 24–48 hours</strong>, which rivals match immediately.
          </p>
        </div>

        <div className="p-5 bg-slate-900 rounded-xl border border-slate-800 space-y-2">
          <div className="flex items-center gap-2 text-amber-400 font-mono text-xs font-semibold">
            <span>Pattern 03</span>
            <span aria-hidden="true">·</span>
            <span>Macro Sensitivity</span>
          </div>
          <h4 className="text-base font-bold text-white">Edmonton Rack & Crude Exposure</h4>
          <p className="text-xs text-slate-400 leading-relaxed">
            Calgary retail fuel is piped from Strathcona/Edmonton refining complexes. Retail pump floors are anchored
            by daily wholesale "rack" prices, which track Western Canadian Select (WCS) and Brent crude benchmarks.
            Large wholesale cost spikes force local retail price jumps within 24 to 72 hours.
          </p>
        </div>
      </div>
    </section>
  );
};
