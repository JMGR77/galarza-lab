/**
 * Calgary Retail Gasoline Price Forecasting Engine
 * End-to-End Machine Learning Operations & Deployment
 */

import React, { useState } from 'react';
import { Navigation } from './components/Navigation';
import { PredictorSection } from './components/PredictorSection';
import { DataOverviewSection } from './components/DataOverviewSection';
import { WranglingSection } from './components/WranglingSection';
import { TransformationSection } from './components/TransformationSection';
import { ModelingValidationSection } from './components/ModelingValidationSection';
import { GovernanceRiskSection } from './components/GovernanceRiskSection';
import { DownloadsSection } from './components/DownloadsSection';
import { triggerDownload } from './data/fuelData';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('deployment');

  const handleTabChange = (tabId: string) => {
    setActiveTab(tabId);
    // Smooth scroll to top of main area
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans">
      {/* Top Bar Navigation */}
      <Navigation activeTab={activeTab} setActiveTab={handleTabChange} />

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-12">
        {/* Render Active View or All Sections */}
        {activeTab === 'deployment' && <PredictorSection />}
        {activeTab === 'overview' && <DataOverviewSection />}
        {activeTab === 'wrangling' && <WranglingSection />}
        {activeTab === 'transformation' && <TransformationSection />}
        {activeTab === 'modeling' && <ModelingValidationSection />}
        {activeTab === 'governance' && <GovernanceRiskSection />}
        {activeTab === 'downloads' && <DownloadsSection />}
      </main>

      {/* Footer */}
      <footer className="mt-16 py-8 border-t border-slate-900 bg-slate-950 text-slate-400 text-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="font-semibold text-white">YYC Fuel Forecaster</span>
            <span aria-hidden="true" className="text-slate-700">·</span>
            <span>Calgary Unleaded Gasoline ML Architecture</span>
            <span aria-hidden="true" className="text-slate-700">·</span>
            <span className="font-mono text-slate-400">2021–2026 Dataset (1,517 Days)</span>
          </div>

          <div className="flex items-center gap-4 text-slate-400">
            <button
              onClick={() => handleTabChange('governance')}
              className="hover:text-slate-200 transition-colors cursor-pointer"
            >
              Governance & Risk
            </button>
            <button
              onClick={() => handleTabChange('downloads')}
              className="hover:text-slate-200 transition-colors cursor-pointer"
            >
              CSV Exports
            </button>
            <button
              onClick={() => triggerDownload('audit_report')}
              className="text-cyan-400 hover:text-cyan-300 font-mono transition-colors cursor-pointer"
            >
              Audit Report
            </button>
          </div>
        </div>
      </footer>
    </div>
  );
}
